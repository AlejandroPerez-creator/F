# Trang liên hệ — Alejandro Pérez

Trang web tĩnh 1 file (`index.html`), phong cách thẻ đội hình bóng đá Tây Ban Nha.

## 1. Thêm ảnh
- **Ảnh đại diện**: đã có sẵn `avatar.jpg` trong thư mục này — cứ để nguyên, hoặc thay bằng ảnh khác (kể cả gif động) miễn giữ đúng tên file, hoặc đổi tên và sửa `src="avatar.jpg"` trong `index.html`.
- **Ảnh nền anime**: đặt file ảnh vào cùng thư mục, đặt tên `bg.jpg`.
(Muốn dùng tên khác thì mở `index.html` và sửa lại.)

## 1b. Nhạc nền
File **`bgmusic.mp3`** đã có sẵn trong thư mục này — nhớ đẩy nó lên GitHub **cùng thư mục** với `index.html`, nếu không nút nhạc ở góc phải màn hình sẽ không phát được gì. (File nhạc nặng nên không nhúng thẳng vào code được — nhúng base64 với file lớn hay bị lỗi phát trên một số trình duyệt.)

## 2. Thiết lập form Liên hệ (Formspree — miễn phí)
1. Vào https://formspree.io và đăng ký tài khoản miễn phí.
2. Tạo form mới, chọn email nhận là `Tn888576@gmail.com`.
3. Formspree sẽ cho bạn một link dạng `https://formspree.io/f/xxxxxxx`.
4. Mở `index.html`, tìm dòng:
   ```html
   <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
   ```
   Thay `YOUR_FORM_ID` bằng ID Formspree vừa tạo.
5. Sau khi deploy, mỗi khi có người điền form ở trang Liên hệ, bạn sẽ nhận được email.

## 3. Đưa lên GitHub
```bash
git init
git add index.html avatar.gif README.md
git commit -m "Trang liên hệ"
git branch -M main
git remote add origin https://github.com/AlejandroPerez-creator/TEN-REPO-CUA-BAN.git
git push -u origin main
```
(Thay `TEN-REPO-CUA-BAN` bằng tên repo bạn tạo trên GitHub.)

## 3. Deploy bằng Vercel
1. Vào https://vercel.com, đăng nhập bằng tài khoản GitHub.
2. Chọn **Add New → Project**.
3. Chọn repo bạn vừa tạo.
4. Vì đây là trang tĩnh (không dùng framework nào), Vercel sẽ tự nhận diện — cứ để mặc định và bấm **Deploy**.
5. Sau ~30 giây bạn sẽ có link dạng `ten-repo.vercel.app`.

Xong — mỗi lần bạn `git push` thêm, Vercel sẽ tự động deploy lại bản mới.
